public class Employee {
    String eid;
    String ename;
    float sal;
    String eaddr;


    public Employee(String eid,String ename,float sal,String eaddr){
        this.eid=eid;
        this.ename=ename;
        this.sal=sal;
        this.eaddr=eaddr;
    }

//    public void getEmployeeDetails(){
//        System.out.println("Employee Details");
//        System.out.println("----------------");
//        System.out.println("Employee Id     : "+eid);
//        System.out.println("Employee Name   : "+ename);
//        System.out.println("Employee Salary : "+sal);
//        System.out.println("Employee Address: "+eaddr);
//
//    }
}


