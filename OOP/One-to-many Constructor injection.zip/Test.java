public class Test {
    public static void main(String []args){
       Employee e1 = new Employee("E-111","AAA",3000,"Hyd");
       Employee e2 = new Employee("E-222","BBB",4000,"Hyd");
       Employee e3 = new Employee("E-333","CCC",5000,"Hyd");
       Employee e4 = new Employee("E-444","DDD",6000,"Hyd");

       Employee[] emps = {e1,e2,e3,e4};
       Department dept = new Department("D-111","Admins",emps);
       dept.getDepartmenDetails();
       //constructor dependancy injection
    }
}
