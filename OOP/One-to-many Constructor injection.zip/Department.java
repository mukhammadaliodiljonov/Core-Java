public class Department {
    String did;
    String dname;
    Employee [] emps;

    public Department(String did, String dname, Employee[] emps){
        this.did=did;
        this.dname=dname;
        this.emps=emps;
    }

    public void getDepartmenDetails(){
        System.out.println("Department Details");
        System.out.println("------------------");
        System.out.println("Department Id   : "+did);
        System.out.println("Department Name : "+dname);
        System.out.println("EID\tENAME\tEADDR:");
        for(Employee emp:emps){
            System.out.println(emp.eid+"\t"+"\t"+emp.ename+"\t"+emp.sal+emp.eaddr);
        }
    }

}
